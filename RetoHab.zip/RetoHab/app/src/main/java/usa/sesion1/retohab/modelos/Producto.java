package usa.sesion1.retohab.modelos;

public class Producto {

    private int id;
    private String titulo;
    private String description;
    private byte[] image;

    public Producto(int id, String titulo, String description, byte[] image) {
        this.id = id;
        this.titulo = titulo;
        this.description = description;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String descripcion) {
        this.description = description;
    }
}
